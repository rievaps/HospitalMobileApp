<?php
require_once '../conn.php';

$response = array();

if ($conn) {
    if (isset($_POST['user_id']) && isset($_POST['medicine']) && isset($_POST['price']) && isset($_POST['qty'])) {
        $user_id = $_POST['user_id'];
        $medicine = $_POST['medicine'];
        $price = $_POST['price'];
        $qty = $_POST['qty'];
        $date = date('d M Y H:i:s');
        $total = $qty * $price;

        $query = "INSERT INTO purchases(user_id, medicine, qty, total, date) 
                        VALUES('$user_id', '$medicine', '$qty', '$total', '$date')";

        $result = mysqli_query($conn, $query);

        if ($result) {
            $response['status'] = 'ok';
            $response['message'] = 'successfully purchased';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'failed to purchase: ' . mysqli_error($conn);
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'all field must be filled';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'failed to purchase';
}
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response);
mysqli_close($conn);
