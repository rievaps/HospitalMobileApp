<?php
require_once '../conn.php';

$response = array();

if ($conn) {
    // Cek parameternya ada yang kosong apa enggak
    if (isset($_POST['id'])) {
        // Ini parameter
        $id = $_POST['id'];
        $query = "DELETE FROM appointments WHERE id=$id";

        $result = mysqli_query($conn, $query);
        $response = array();

        if ($result) {
            $response['status'] = 'success';
            $response['message'] = 'successfully delete data';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'failed to delete data: ' . mysqli_error($conn);
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'id must not be empty';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'failed to delete data';
}
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response);
mysqli_close($conn);
