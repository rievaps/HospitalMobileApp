<?php
require_once '../conn.php';

$response = array();

if ($conn) {
    // Cek parameternya ada yang kosong apa enggak
    if (isset($_POST['user_id'])) {
        // Ini parameter
        $user_id = $_POST['user_id'];
        $query = "SELECT * FROM appointments WHERE user_id=$user_id";

        $result = mysqli_query($conn, $query);
        $response = array();

        if ($result) {
            $response['status'] = 'success';
            $response['message'] = 'successfully fetched data';
            $response['data'] = $result->fetch_all(MYSQLI_ASSOC);
        } else {
            $response['status'] = 'error';
            $response['message'] = 'failed to fetch data: ' . mysqli_error($conn);
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'user id must not be empty';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'failed to fetch data';
}
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response);
mysqli_close($conn);
