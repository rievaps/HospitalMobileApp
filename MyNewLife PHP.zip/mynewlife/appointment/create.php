<?php
require_once '../conn.php';

if ($conn) {
    // Cek parameternya ada yang kosong apa enggak
    if (isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['email']) && isset($_POST['doctor']) && isset($_POST['date']) && isset($_POST['type']) && isset($_POST['user_id'])) {
        // Ini parameter
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $doctor = $_POST['doctor'];
        $date = $_POST['date'];
        $type = $_POST['type'];
        $user_id = $_POST['user_id'];

        $insert = "INSERT INTO appointments(first_name, last_name, email, doctor, date, type, user_id) 
                        VALUES('$first_name', '$last_name', '$email', '$doctor', '$date', '$type', '$user_id')";
        $result = mysqli_query($conn, $insert);
        $response = array();

        if ($result) {
            $response['status'] = 'ok';
            $response['message'] = 'successfully create an appointment';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'failed to make appointment: ' . mysqli_error($conn);
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'all field must be filled';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'failed to make appointment';
}
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response);
mysqli_close($conn);
