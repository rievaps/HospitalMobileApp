<?php
require_once '../conn.php';

if ($conn) {
    // Cek parameternya ada yang kosong apa enggak
    if (isset($_POST['id']) && isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['email']) && isset($_POST['doctor']) && isset($_POST['date']) && isset($_POST['type'])) {
        // Ini parameter
        $id = $_POST['id'];
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $doctor = $_POST['doctor'];
        $date = $_POST['date'];
        $type = $_POST['type'];

        $insert = "UPDATE appointments SET first_name='$first_name', last_name='$last_name', email='$email',
                    doctor='$doctor', date='$date', type='$type' where id=$id";
        $result = mysqli_query($conn, $insert);
        $response = array();

        if ($result) {
            $response['status'] = 'ok';
            $response['message'] = 'successfully update data';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'failed to update data: ' . mysqli_error($conn);
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'all field must be filled';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'failed to update data';
}
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response);
mysqli_close($conn);
